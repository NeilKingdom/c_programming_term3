/* PROGRAM:  llist.c 
   AUTHOR:    
   DATE:     20/10/11 
   	     
   TOPIC:    simple linked list implementation 
   PURPOSE:  Simple data structures 
   NOTES:   
             
*/

/**************************************************************************/
/* Declare include files
 **************************************************************************/
#include "llist.h"

/**************************************************************************/
/* Provided functions
 **************************************************************************/
 
/**************************************************************************/
/* llist_push:  Add an element to the head of the list
 **************************************************************************/
int llist_push( node_t **headRef, int data ) {

	node_t *new;

	if ( ( new = ( node_t *) malloc( sizeof( node_t ) ) ) == NULL )
		return EXIT_FAILURE;
	
	new->data = data;
	new->next = *headRef;
	*headRef  = new; 

	return 0;

}
/**************************************************************************/
/* llist_pop:   Removes first element of the list
 **************************************************************************/
void llist_pop   ( node_t **headRef ) {

	node_t *h = * headRef;
	
	if ( h == NULL ) return;
	
	*headRef = h->next;
	free( h );

	return;
}
/**************************************************************************/
/* llist_size:  Returns number of elements in the list
 **************************************************************************/ 
int  llist_size  ( node_t * head ) {
	int cnt = 0;
	
	struct node * tmp = head;

	while( tmp != NULL ) {
		cnt++;
		tmp = tmp->next;
	}
	return cnt;

}
/**************************************************************************/
/* llist_print:   Prints a list
 **************************************************************************/
void llist_print ( node_t * head ){

	int nodes = 0;
	struct node *current = head;


	fprintf( stdout, "{ " );
	while( current != NULL ) {
		fprintf( stdout, "%4d -->", current->data );
		nodes++;
		current = current->next;
	}
	fprintf( stdout, " NULL }\n" );
		
	fprintf(stdout, "Number of elements in the list: %d\n", nodes );

	return;

}

/**************************************************************************/
/* Functions to be implemented by you
 **************************************************************************/
void llist_contains ( node_t *h, int value );
int  llist_count    ( node_t *h, int value );
int  llist_find     ( node_t *h, int value ) ;
int  llist_is_equal ( node_t *h1, node_t *h2 );

void llist_addlast  ( node_t **href, int value );
void llist_insert   ( node_t **href, int value , int index );
void llist_remove   ( node_t **href, int value );
void llist_free     ( node_t **href );

